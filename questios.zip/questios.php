<?php 
				
$q1 =Mansir::get_number_of_Q2("health_info_mu_record", "q1", $this_user_id);
$q2 =Mansir::get_number_of_Q2("health_info_mu_record", "q2", $this_user_id);
$q3 =Mansir::get_number_of_Q2("health_info_mu_record", "q3", $this_user_id);
$q4 =Mansir::get_number_of_Q2("health_info_mu_record", "q4", $this_user_id);
$q5 =Mansir::get_number_of_Q2("health_info_mu_record", "q5", $this_user_id);
$q6 =Mansir::get_number_of_Q2("health_info_mu_record", "q6", $this_user_id);
$q7 =Mansir::get_number_of_Q2("health_info_mu_record", "q7", $this_user_id);
$q8 =Mansir::get_number_of_Q2("health_info_mu_record", "q8", $this_user_id);

$him = $q1+$q2+$q3+$q4+$q5+$q6+$q7+$q8; 

$q9 =Mansir::get_number_of_Q2("opd", "q9", $this_user_id);
$q10 =Mansir::get_number_of_Q2("opd", "q10", $this_user_id);
$q11 =Mansir::get_number_of_Q2("opd", "q11", $this_user_id);
$q12 =Mansir::get_number_of_Q2("opd", "q12", $this_user_id);
$q13 =Mansir::get_number_of_Q2("opd", "q13", $this_user_id);
$q14 =Mansir::get_number_of_Q2("opd", "q14", $this_user_id);
$q15 =Mansir::get_number_of_Q2("opd", "q15", $this_user_id);
$q16 =Mansir::get_number_of_Q2("opd", "q16",  $this_user_id);
$q17 =Mansir::get_number_of_Q2("opd", "q17", $this_user_id);
$q18 =Mansir::get_number_of_Q2("opd", "q18", $this_user_id);
$q19 =Mansir::get_number_of_Q2("opd", "q19", $this_user_id);
$q20 =Mansir::get_number_of_Q2("opd", "q20", $this_user_id);
$q21 =Mansir::get_number_of_Q2("opd", "q21", $this_user_id);
$q22 =Mansir::get_number_of_Q2("opd", "q22", $this_user_id);
$q23 =Mansir::get_number_of_Q2("opd", "q23", $this_user_id);
$q24 =Mansir::get_number_of_Q2("opd", "q24", $this_user_id);
$q25 =Mansir::get_number_of_Q2("opd", "q25", $this_user_id);
$q26 =Mansir::get_number_of_Q2("opd", "q26", $this_user_id);
$q27 =Mansir::get_number_of_Q2("opd", "q27", $this_user_id);
$q28 =Mansir::get_number_of_Q2("opd", "q28", $this_user_id);
$q29 =Mansir::get_number_of_Q2("opd", "q29", $this_user_id);
$q30 =Mansir::get_number_of_Q2("opd", "q30", $this_user_id);

$opd_opd = $q9+$q10+$q11+$q12+$q13+$q14+$q15+$q16+$q17+$q18+$q19+$q20+
				 $q21+$q22+$q23+$q24+$q25+$q26+$q27+$q28+$q29+$q30;

$q31 =Mansir::get_number_of_Q2("pharmacy", "q31", $this_user_id);
$q32 =Mansir::get_number_of_Q2("pharmacy", "q32", $this_user_id);
$q33 =Mansir::get_number_of_Q2("pharmacy", "q33", $this_user_id);
$q34 =Mansir::get_number_of_Q2("pharmacy", "q34", $this_user_id);
$q35 =Mansir::get_number_of_Q2("pharmacy", "q35", $this_user_id);
$q36 =Mansir::get_number_of_Q2("pharmacy", "q36", $this_user_id);
$q37 =Mansir::get_number_of_Q2("pharmacy", "q37", $this_user_id);
$q38 =Mansir::get_number_of_Q2("pharmacy", "q38", $this_user_id);
$q39 =Mansir::get_number_of_Q2("pharmacy", "q39", $this_user_id);
$q40 =Mansir::get_number_of_Q2("pharmacy", "q40", $this_user_id);
$q41 =Mansir::get_number_of_Q2("pharmacy", "q41", $this_user_id);
$q42 =Mansir::get_number_of_Q2("pharmacy", "q42", $this_user_id);
$q43 =Mansir::get_number_of_Q2("pharmacy", "q43", $this_user_id);
$q44 =Mansir::get_number_of_Q2("pharmacy", "q44", $this_user_id);
$q45 =Mansir::get_number_of_Q2("pharmacy", "q45", $this_user_id);
$q46=Mansir::get_number_of_Q2("pharmacy", "q46", $this_user_id);
$q47 =Mansir::get_number_of_Q2("pharmacy", "q47", $this_user_id);
$q48 =Mansir::get_number_of_Q2("pharmacy", "q48", $this_user_id);
$q49 =Mansir::get_number_of_Q2("pharmacy", "q49", $this_user_id);
$q50 =Mansir::get_number_of_Q2("pharmacy", "q50", $this_user_id);
$q51 =Mansir::get_number_of_Q2("pharmacy", "q51", $this_user_id);
$q52 =Mansir::get_number_of_Q2("pharmacy", "q52", $this_user_id);
$q53 =Mansir::get_number_of_Q2("pharmacy", "q53", $this_user_id);
$q54 =Mansir::get_number_of_Q2("pharmacy", "q54", $this_user_id);
$q55 =Mansir::get_number_of_Q2("pharmacy", "q55", $this_user_id);
$q56 =Mansir::get_number_of_Q2("pharmacy", "q56", $this_user_id);
$q57 =Mansir::get_number_of_Q2("pharmacy", "q57", $this_user_id);
$q58 =Mansir::get_number_of_Q2("pharmacy", "q58", $this_user_id);

$pharmacy_ph = $q31+$q32+$q33+$q34+$q35+$q36+$q37+$q38+$q39+$q40+
				 $q41+$q42+$q43+$q44+$q45+$q46+$q47+$q48+$q49+$q50+
				 $q51+$q52+$q53+$q54+$q55+$q56+$q57+$q58;


$q59 =Mansir::get_number_of_Q2("lab", "q59", $this_user_id);
$q60 =Mansir::get_number_of_Q2("lab", "q60", $this_user_id);
$q61 =Mansir::get_number_of_Q2("lab", "q61", $this_user_id);
$q62 =Mansir::get_number_of_Q2("lab", "q62", $this_user_id);
$q63 =Mansir::get_number_of_Q2("lab", "q63", $this_user_id);
$q64 =Mansir::get_number_of_Q2("lab", "q64", $this_user_id);
$q65 =Mansir::get_number_of_Q2("lab", "q65", $this_user_id);
$q66 =Mansir::get_number_of_Q2("lab", "q66", $this_user_id);
$q67 =Mansir::get_number_of_Q2("lab", "q67", $this_user_id);
$q68 =Mansir::get_number_of_Q2("lab", "q68", $this_user_id);
$q69 =Mansir::get_number_of_Q2("lab", "q69", $this_user_id);
$q70 =Mansir::get_number_of_Q2("lab", "q70", $this_user_id);
$q71 =Mansir::get_number_of_Q2("lab", "q71", $this_user_id);
$q72 =Mansir::get_number_of_Q2("lab", "q72", $this_user_id);
$q73 =Mansir::get_number_of_Q2("lab", "q73", $this_user_id);
$q74 =Mansir::get_number_of_Q2("lab", "q74", $this_user_id);
$q75 =Mansir::get_number_of_Q2("lab", "q75", $this_user_id);
$q76 =Mansir::get_number_of_Q2("lab", "q76", $this_user_id);
$q77 =Mansir::get_number_of_Q2("lab", "q77", $this_user_id);
$q78 =Mansir::get_number_of_Q2("lab", "q78", $this_user_id);
$q79 =Mansir::get_number_of_Q2("lab", "q79", $this_user_id);
$q80 =Mansir::get_number_of_Q2("lab", "q80", $this_user_id);
$q81 =Mansir::get_number_of_Q2("lab", "q81", $this_user_id);
$q82 =Mansir::get_number_of_Q2("lab", "q82", $this_user_id);

$lab_lab = $q59+$q60+
				 $q61+$q62+$q63+$q64+$q65+$q66+$q67+$q68+$q69+$q70+
				 $q71+$q72+$q73+$q74+$q75+$q76+$q77+$q78+$q79+$q80+
				 $q81+$q82;

$q83 =Mansir::get_number_of_Q2("a_and_e", "q83", $this_user_id);
$q84 =Mansir::get_number_of_Q2("a_and_e", "q84", $this_user_id);
$q85 =Mansir::get_number_of_Q2("a_and_e", "q85", $this_user_id);
$q86 =Mansir::get_number_of_Q2("a_and_e", "q86", $this_user_id);
$q87 =Mansir::get_number_of_Q2("a_and_e", "q87", $this_user_id);
$q88 =Mansir::get_number_of_Q2("a_and_e", "q88", $this_user_id);
$q89 =Mansir::get_number_of_Q2("a_and_e", "q89", $this_user_id);
$q90 =Mansir::get_number_of_Q2("a_and_e", "q90", $this_user_id);
$q91 =Mansir::get_number_of_Q2("a_and_e", "q91", $this_user_id);

$a_and_e_a_and_e = $q83+$q84+$q85+$q86+$q87+$q88+$q89+$q90+
				 $q91;

$q92 =Mansir::get_number_of_Q2("labour_room", "q92", $this_user_id);
$q93 =Mansir::get_number_of_Q2("labour_room", "q93", $this_user_id);
$q94 =Mansir::get_number_of_Q2("labour_room", "q94", $this_user_id);
$q95 =Mansir::get_number_of_Q2("labour_room", "q95", $this_user_id);
$q96 =Mansir::get_number_of_Q2("labour_room", "q96", $this_user_id);
$q97 =Mansir::get_number_of_Q2("labour_room", "q97", $this_user_id);
$q98 =Mansir::get_number_of_Q2("labour_room", "q98", $this_user_id);
$q99 =Mansir::get_number_of_Q2("labour_room", "q99", $this_user_id);
$q100 =Mansir::get_number_of_Q2("labour_room", "q100", $this_user_id);
$q101 =Mansir::get_number_of_Q2("labour_room", "q101", $this_user_id);
$q102 =Mansir::get_number_of_Q2("labour_room", "q102", $this_user_id);
$q103 =Mansir::get_number_of_Q2("labour_room", "q103", $this_user_id);
$q104 =Mansir::get_number_of_Q2("labour_room", "q104", $this_user_id);
$q105 =Mansir::get_number_of_Q2("labour_room", "q105", $this_user_id);
$q106 =Mansir::get_number_of_Q2("labour_room", "q106", $this_user_id);

$labouroom = $q92+$q93+$q94+$q95+$q96+$q97+$q98+$q99+$q100+
				 $q101+$q102+$q103+$q104+$q105+$q106;

$q107 =Mansir::get_number_of_Q2("inpatient", "q107", $this_user_id);
$q108 =Mansir::get_number_of_Q2("inpatient", "q108", $this_user_id);
$q109 =Mansir::get_number_of_Q2("inpatient", "q109", $this_user_id);
$q110 =Mansir::get_number_of_Q2("inpatient", "q110", $this_user_id);
$q111 =Mansir::get_number_of_Q2("inpatient", "q111", $this_user_id);
$q112 =Mansir::get_number_of_Q2("inpatient", "q112", $this_user_id);
$q113 =Mansir::get_number_of_Q2("inpatient", "q113", $this_user_id);
$q114 =Mansir::get_number_of_Q2("inpatient", "q114", $this_user_id);

$in_patient = $q107+$q108+$q109+$q110+
				 $q111+$q112+$q113+$q114;

$q115 =Mansir::get_number_of_Q2("finace", "q115", $this_user_id);
$q116 =Mansir::get_number_of_Q2("finace", "q116", $this_user_id);
$q117 =Mansir::get_number_of_Q2("finace", "q117", $this_user_id);
$q118 =Mansir::get_number_of_Q2("finace", "q118", $this_user_id); 

$finance = $q115+$q116+$q117+$q118;
					

$number_of_Yes = $q1+$q2+$q3+$q4+$q5+$q6+$q7+$q8+$q9+$q10+
				 $q11+$q12+$q13+$q14+$q15+$q16+$q17+$q18+$q19+$q20+
				 $q21+$q22+$q23+$q24+$q25+$q26+$q27+$q28+$q29+$q30+
				 $q31+$q32+$q33+$q34+$q35+$q36+$q37+$q38+$q39+$q40+
				 $q41+$q42+$q43+$q44+$q45+$q46+$q47+$q48+$q49+$q50+
				 $q51+$q52+$q53+$q54+$q55+$q56+$q57+$q58+$q59+$q60+
				 $q61+$q62+$q63+$q64+$q65+$q66+$q67+$q68+$q69+$q70+
				 $q71+$q72+$q73+$q74+$q75+$q76+$q77+$q78+$q79+$q80+
				 $q81+$q82+$q83+$q84+$q85+$q86+$q87+$q88+$q89+$q90+
				 $q91+$q92+$q93+$q94+$q95+$q96+$q97+$q98+$q99+$q100+
				 $q101+$q102+$q103+$q104+$q105+$q106+$q107+$q108+$q109+$q110+
				 $q111+$q112+$q113+$q114+$q115+$q116+$q117+$q118
					;
//echo $number_of_Yes;
//exit();

		?>